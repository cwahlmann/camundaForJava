var registerBpmnJSPlugin = require('camunda-modeler-plugin-helpers').registerBpmnJSPlugin;
var plugin = require('./PropertyInfoPlugin');

registerBpmnJSPlugin(plugin);
