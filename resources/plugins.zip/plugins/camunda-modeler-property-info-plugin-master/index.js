'use strict';

module.exports = {
  name: 'Camunda Property Infos',
  menu: './menu/menu.js',
  script: './client/client-bundle.js',
  style: './style/style.css'
};
