'use strict';

module.exports = {
  name: 'BPMN Linter',
  script: './dist/client.js',
  style: './dist/bpmn-js-bpmnlint.css',
  menu: './menu.js'
};
