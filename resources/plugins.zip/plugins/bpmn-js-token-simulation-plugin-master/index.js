'use strict';

module.exports = {
  name: 'bpmn-js Token Simulation',
  script: './client/client.bundle.js',
  style: './client/assets/bpmn-js-token-simulation/css/bpmn-js-token-simulation.css',
  menu: './menu.js'
};
