'use strict';

module.exports = {
  name: 'Tooltip Plugin',
  menu: './menu/menu.js',
  script: './dist/client.js',
  style: './style/style.css'
};
