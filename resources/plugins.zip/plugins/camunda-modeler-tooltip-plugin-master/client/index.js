import {
    registerBpmnJSPlugin
  } from 'camunda-modeler-plugin-helpers';
  
  import plugin from './TooltipInfoService';
  
  registerBpmnJSPlugin(plugin);
  